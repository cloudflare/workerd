from . import create_proxy


class PyProxyShape:
    shape: int

    def __init__(self, obj: Any):
        px = create_proxy(obj)
        self.shape = getattr(px, "$$flags")
        px.destroy()


class JsInt:
    pass


class JsBigInt:
    pass
